var http = require('http');
const express= require('express')
const app=express();
const bodyParser= require('body-parser')
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
const server = http.createServer(app);
const cors = require('cors');
const jwt = require('jsonwebtoken');
const expressJwt = require('express-jwt');
const conn= require('./connection');
const sendtoken = require('./Token').sendToken;

app.use(cors());

app.post('/',(req,res)=>{
    
    res.send("sucess")
})
app.post('/register',(req,res)=>{
    // const encryptedPassword = await bcrypt.hash(req.body.password, saltRounds)
    console.log(req.body,"reg body");
    var token = jwt.sign({userID: req.body.id}, 'todo-app-super-shared-secret', {expiresIn: '2h'});

    var users={
        "firstName":req.body.firstName,
        "lastName":req.body.lastName,
        "username":req.body.username,
       "password":req.body.password  ,
      "token":token
       }
    console.log(req.body,"register");
    conn.query('INSERT INTO register SET ?',users, function (error, results, fields) {
        if (error) {
          res.send({
            "code":400,
            "failed":"error ocurred"
          })
        } else {
          // res.send({
          //   "code":200,
          //   "success":"user registered sucessfully"
          //     });
          res.send(JSON.stringify(results))

          }

      });
console.log(conn.query);

    // conn.query("INSERT INTO `register` ( `firstName`, `lastName`,`username`,`password`)VALUES('"+req.body.firstName+"','"+req.body.lastName+"','"+req.bosy.username+"','"+req.body.password+"')");
    // console.log(conn,"conn");
    
})

app.get('/reg',(req,res)=>{
  var selectQuery="select * from register";
  conn.query(selectQuery,function(err,result){
// console.log(result,"result values");
 res.send(JSON.stringify(result))
  })
})
app.post('/users',(req,res)=>{
    console.log(req.body,"/api/users");
    var users={
      "username":req.body.username,
     "password":req.body.password
   }
  console.log(req.body.username,"login");
// console.log(req.body.id,"id");
  var username=req.body.username;
  var password =req.body.password;
  var selectQuery="select token from register where username="+JSON.stringify(username);
  conn.query(selectQuery,function(err,queryResponse){
  console.log(queryResponse[0].token,"res-checking");
  console.log("loginn");
  // res.send(req.body, username);
let response= JSON.stringify(queryResponse)
  if(queryResponse[0].token == null){
    console.log("null");

     console.log(queryResponse[0].token,"null");

  }
  else if(queryResponse[0].token != null){

    let insertQuery ="INSERT into users(username,password)values("+JSON.stringify(username)+","+JSON.stringify(password)+")"
    console.log(insertQuery,"query");
    conn.query(insertQuery,function(err,insertQueryResponse){
  console.log(insertQueryResponse,"insrt");
    });
  
  //  console.log(token,"not null");
  }
 
 
  res.send(JSON.stringify(queryResponse[0].token));


})

})
server.listen(3000, function () {
    console.log('Express server listening on ', 3000);
  });
