module.exports = {
    secret: 'mkdyfysrdabnkvfppieru72348202HSGQ'
};